import heapq
import math
import time 
from heuristics import manhattan, euclidean

# Node structure for A* / GBFS
class Node:
    def __init__(self, position, parent=None, g=0, h=0):
        self.position = position
        self.parent = parent
        self.g = g
        self.h = h
    def f(self):
        return self.g + self.h
    def __lt__(self, other):
        return self.f() < other.f()

def reconstruct_path(node):
    path = []
    while node:
        path.append(node.position)
        node = node.parent
    return path[::-1]

# A* algorithm
def a_star(grid, start, goal, heuristic=manhattan):
    start_time = time.time()
    open_list = []
    heapq.heappush(open_list, (0, Node(start)))
    visited = set()
    frontier_nodes = []
    visited_nodes = []

    while open_list:
        current_f, current_node = heapq.heappop(open_list)
        visited.add(current_node.position)
        visited_nodes.append(current_node.position)

        if current_node.position == goal:
            path = reconstruct_path(current_node)
            exec_time = (time.time() - start_time) * 1000
            return path, len(visited_nodes), len(path), exec_time, frontier_nodes, visited_nodes

        r, c = current_node.position
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < grid.rows and 0 <= nc < grid.cols:
                if grid.grid[nr][nc] == 1:
                    continue
                if (nr,nc) in visited:
                    continue
                g_cost = current_node.g + 1
                h_cost = heuristic((nr,nc), goal)
                neighbor = Node((nr,nc), current_node, g_cost, h_cost)
                heapq.heappush(open_list, (neighbor.f(), neighbor))
                frontier_nodes.append((nr,nc))

    return [], len(visited_nodes), 0, 0, frontier_nodes, visited_nodes

# Greedy Best-First Search
def greedy_bfs(grid, start, goal, heuristic=manhattan):
    start_time = time.time()
    open_list = []
    heapq.heappush(open_list, (0, Node(start)))
    visited = set()
    frontier_nodes = []
    visited_nodes = []

    while open_list:
        current_h, current_node = heapq.heappop(open_list)
        visited.add(current_node.position)
        visited_nodes.append(current_node.position)

        if current_node.position == goal:
            path = reconstruct_path(current_node)
            exec_time = (time.time() - start_time) * 1000
            return path, len(visited_nodes), len(path), exec_time, frontier_nodes, visited_nodes

        r, c = current_node.position
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < grid.rows and 0 <= nc < grid.cols:
                if grid.grid[nr][nc] == 1:
                    continue
                if (nr,nc) in visited:
                    continue
                h_cost = heuristic((nr,nc), goal)
                neighbor = Node((nr,nc), current_node, 0, h_cost)
                heapq.heappush(open_list, (neighbor.h, neighbor))
                frontier_nodes.append((nr,nc))

    return [], len(visited_nodes), 0, 0, frontier_nodes, visited_nodes