import random

class Grid:
    def __init__(self, rows, cols, obstacle_density=0.3):
        self.rows = rows
        self.cols = cols
        self.grid = [[0 for _ in range(cols)] for _ in range(rows)]
        self.start = (0, 0)
        self.goal = (rows-1, cols-1)
        self.obstacle_density = obstacle_density
        self.generate_random_obstacles()

    def generate_random_obstacles(self):
        for r in range(self.rows):
            for c in range(self.cols):
                if (r, c) == self.start or (r, c) == self.goal:
                    continue
                if random.random() < self.obstacle_density:
                    self.grid[r][c] = 1

    def toggle_obstacle(self, row, col):
        if (row, col) not in [self.start, self.goal]:
            self.grid[row][col] = 0 if self.grid[row][col] == 1 else 1

    def is_blocked(self, pos):
        r, c = pos
        return self.grid[r][c] == 1

    def neighbors(self, pos):
        r, c = pos
        moves = [(r-1, c),(r+1,c),(r,c-1),(r,c+1)]
        result = []
        for nr, nc in moves:
            if 0 <= nr < self.rows and 0 <= nc < self.cols and self.grid[nr][nc] == 0:
                result.append((nr,nc))
        return result