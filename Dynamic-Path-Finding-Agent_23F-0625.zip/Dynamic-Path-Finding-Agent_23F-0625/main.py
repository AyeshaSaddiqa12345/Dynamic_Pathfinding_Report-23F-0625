from grid import Grid 
from gui import GUI

if __name__ == "__main__":
    # Let user define grid size
    rows, cols = 20, 30
    # Create grid with obstacle density 20%
    grid = Grid(rows, cols, obstacle_density=0.2)
    # Initialize GUI
    gui = GUI(grid)
    # Run the dynamic simulation
    gui.run_dynamic()