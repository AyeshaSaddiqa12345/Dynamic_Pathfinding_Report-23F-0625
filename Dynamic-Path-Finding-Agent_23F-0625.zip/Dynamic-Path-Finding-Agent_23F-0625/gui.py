import pygame
from dynamic import spawn_dynamic_obstacle

CELL_SIZE = 25
FONT_SIZE = 20

class GUI:
    def __init__(self, grid):
        self.grid = grid
        self.rows = grid.rows
        self.cols = grid.cols
        self.width = self.cols * CELL_SIZE
        self.height = self.rows * CELL_SIZE + 100  # extra space for buttons/metrics

        pygame.init()
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Dynamic Pathfinding Agent")
        self.font = pygame.font.SysFont(None, FONT_SIZE)

        # User selections
        self.algorithm_name = "A*"
        self.heuristic_name = "Manhattan"
        self.algorithm = None  # Will be set by main.py or buttons
        self.heuristic = None  # Will be set by main.py or buttons

        self.simulation_started = False

    # Draw grid, path, frontier, visited nodes
    def draw_grid(self, path=[], frontier=[], visited=[]):
        self.screen.fill((255, 255, 255))
        for r in range(self.rows):
            for c in range(self.cols):
                color = (255, 255, 255)
                if self.grid.grid[r][c] == 1:
                    color = (0, 0, 0)
                elif (r, c) == self.grid.start:
                    color = (255, 165, 0)
                elif (r, c) == self.grid.goal:
                    color = (128, 0, 128)
                pygame.draw.rect(self.screen, color, (c*CELL_SIZE, r*CELL_SIZE, CELL_SIZE, CELL_SIZE))
                pygame.draw.rect(self.screen, (200, 200, 200), (c*CELL_SIZE, r*CELL_SIZE, CELL_SIZE, CELL_SIZE), 1)

        # Draw frontier nodes (yellow)
        for node in frontier:
            pygame.draw.rect(self.screen, (255, 255, 0), (node[1]*CELL_SIZE, node[0]*CELL_SIZE, CELL_SIZE, CELL_SIZE))

        # Draw visited nodes (blue)
        for node in visited:
            pygame.draw.rect(self.screen, (0, 0, 255), (node[1]*CELL_SIZE, node[0]*CELL_SIZE, CELL_SIZE, CELL_SIZE))

        # Draw final path (green)
        for node in path:
            pygame.draw.rect(self.screen, (0, 255, 0), (node[1]*CELL_SIZE, node[0]*CELL_SIZE, CELL_SIZE, CELL_SIZE))

        # Draw buttons & metrics area
        pygame.draw.rect(self.screen, (220, 220, 220), (0, self.rows*CELL_SIZE, self.width, 100))
        self.draw_buttons()
        pygame.display.flip()

    # Draw algorithm and heuristic buttons
    def draw_buttons(self):
        alg_text = self.font.render(f"Algorithm: {self.algorithm_name} (Click to toggle)", True, (0,0,0))
        heur_text = self.font.render(f"Heuristic: {self.heuristic_name} (Click to toggle)", True, (0,0,0))
        self.screen.blit(alg_text, (10, self.rows*CELL_SIZE + 10))
        self.screen.blit(heur_text, (10, self.rows*CELL_SIZE + 40))

    # Draw real-time metrics
    def draw_metrics(self, nodes_visited, path_cost, exec_time):
        nodes_text = self.font.render(f"Nodes Visited: {nodes_visited}", True, (0,0,0))
        cost_text = self.font.render(f"Path Cost: {path_cost}", True, (0,0,0))
        time_text = self.font.render(f"Execution Time: {int(exec_time)} ms", True, (0,0,0))
        self.screen.blit(nodes_text, (400, self.rows*CELL_SIZE + 10))
        self.screen.blit(cost_text, (400, self.rows*CELL_SIZE + 35))
        self.screen.blit(time_text, (400, self.rows*CELL_SIZE + 60))

    # Toggle algorithm selection
    def toggle_algorithm(self):
        from algorithms import a_star, greedy_bfs
        if self.algorithm_name == "A*":
            self.algorithm_name = "GBFS"
            self.algorithm = greedy_bfs
        else:
            self.algorithm_name = "A*"
            self.algorithm = a_star

    # Toggle heuristic selection
    def toggle_heuristic(self):
        from heuristics import manhattan, euclidean
        if self.heuristic_name == "Manhattan":
            self.heuristic_name = "Euclidean"
            self.heuristic = euclidean
        else:
            self.heuristic_name = "Manhattan"
            self.heuristic = manhattan

    # Handle mouse clicks (walls or buttons)
    def handle_mouse_click(self, pos):
        x, y = pos
        if y < self.rows * CELL_SIZE:
            col = x // CELL_SIZE
            row = y // CELL_SIZE
            self.grid.toggle_obstacle(row, col)
        else:
            # Buttons area
            if 10 <= x <= 350:
                if 10 <= y - self.rows*CELL_SIZE <= 30:
                    self.toggle_algorithm()
                elif 40 <= y - self.rows*CELL_SIZE <= 60:
                    self.toggle_heuristic()

    # Main simulation loop
    def run_dynamic(self):
        clock = pygame.time.Clock()
        running = True

        path = []
        current_index = 0
        frontier = []
        visited_nodes = []
        visited_count = 0
        path_cost = 0
        exec_time = 0

        while running:
            clock.tick(10)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if not self.simulation_started:
                        self.handle_mouse_click(pygame.mouse.get_pos())
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        # Start or restart simulation
                        self.simulation_started = True
                        if self.algorithm is None:
                            from algorithms import a_star
                            self.algorithm = a_star
                        if self.heuristic is None:
                            from heuristics import manhattan
                            self.heuristic = manhattan
                        # Reset simulation variables
                        current_index = 0
                        path, visited_count, path_cost, exec_time, frontier, visited_nodes = self.algorithm(
                            self.grid, self.grid.start, self.grid.goal, self.heuristic)

            # Simulation step
            if self.simulation_started and path and current_index < len(path):
                # Spawn dynamic obstacles along remaining path
                if spawn_dynamic_obstacle(self.grid, 0.05, path[current_index:]):
                    path, visited_count, path_cost, exec_time, frontier, visited_nodes = self.algorithm(
                        self.grid, path[current_index], self.grid.goal, self.heuristic)
                    current_index = 0
                current_index += 1
            elif self.simulation_started and current_index >= len(path):
                # Path finished
                self.simulation_started = False
                path = []
                frontier = []
                visited_nodes = []
                current_index = 0

            # Draw everything
            self.draw_grid(
                path=path[:current_index] if path else [],
                frontier=frontier,
                visited=visited_nodes
            )
            if path:
                self.draw_metrics(visited_count, path_cost, exec_time)