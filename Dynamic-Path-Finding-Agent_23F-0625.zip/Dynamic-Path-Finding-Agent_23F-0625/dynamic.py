import random

def spawn_dynamic_obstacle(grid, probability=0.05, current_path=None):
    r = random.randint(0, grid.rows-1)
    c = random.randint(0, grid.cols-1)
    pos = (r, c)
    if pos in [grid.start, grid.goal]:
        return False
    if current_path and pos not in current_path:
        return False
    if random.random() < probability:
        grid.grid[r][c] = 1
        return True
    return False